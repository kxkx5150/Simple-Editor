chrome.app.runtime.onLaunched.addListener(function(launchData) {
    launchAPP({
        width:500,
        height:350,
        minWidth:250,
        minHeight:100, 
    });
});
function launchAPP(windopt){
    var opts = {
        id:'main',
        frame:"none",
        outerBounds:windopt
    };
    chrome.app.window.create('index.html',opts,function(mainWindow) {
        mainWindow.onClosed.addListener(function(e) {

        })
    });
}
