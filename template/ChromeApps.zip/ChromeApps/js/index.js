document.addEventListener("DOMContentLoaded", function(e) {
    addCustomFrameEvent();
    
},false);

function addCustomFrameEvent(){
    document.getElementsByClassName("modal-awesome-minus")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-max")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-close")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-pin")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-full")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-file")[0].addEventListener("click",clickCustomFrameItem,true);
    document.getElementsByClassName("modal-awesome-folder")[0].addEventListener("click",clickCustomFrameItem,true);
}
function clickCustomFrameItem(e){
    if(this.classList.contains("modal-awesome-close")){
        chrome.app.window.current().close();
    }else if(this.classList.contains("modal-awesome-minus")){
        chrome.app.window.current().minimize();
    }else if(this.classList.contains("modal-awesome-pin")){
        var crntw = chrome.app.window.current();
        if(crntw.isAlwaysOnTop()){
            this.classList.remove("alwaysontop")
            crntw.setAlwaysOnTop(false);
        }else{
            this.classList.add("alwaysontop")
            crntw.setAlwaysOnTop(true);
        }    
    }else if(this.classList.contains("modal-awesome-max")){
        var crntw = chrome.app.window.current();
        if(crntw.isMaximized() || crntw.isFullscreen()){
            crntw.restore();
        }else{
            crntw.maximize();
        }
    }else if(this.classList.contains("modal-awesome-full")){
        var crntw = chrome.app.window.current();
        if(crntw.isMaximized() || crntw.isFullscreen()){
            crntw.restore();
        }else{
            crntw.fullscreen();
        }
    }else if(this.classList.contains("modal-awesome-file")){
        chrome.fileSystem.chooseEntry({
            type:"openFile",
            accepts:[{
                mimeTypes: [],
                extensions: []
            }],
            acceptsMultiple: true
        },function(fileEntries){
            if(fileEntries&&fileEntries.length > 0){ 

            }
        });
    }else if(this.classList.contains("modal-awesome-folder")){
        chrome.fileSystem.chooseEntry({
            type:"openDirectory"
        },function(fileEntrie){
            if(fileEntrie){

            }
        });
    }
}
