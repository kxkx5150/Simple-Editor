document.addEventListener("DOMContentLoaded", function() {

},false);

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
	sendResponse({});
});
chrome.runtime.sendMessage({msg:"content script"});
