var sendport = chrome.runtime.connect();
document.addEventListener("DOMContentLoaded", function() {

},false);
chrome.runtime.getBackgroundPage(function(bg){

});
sendport.postMessage({msg: "popup"});
