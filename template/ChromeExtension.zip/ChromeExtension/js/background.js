chrome.runtime.onConnect.addListener(function(port) {
    port.onMessage.addListener(function(msg) {

    });
});
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    chrome.tabs.sendMessage(sender.tab.id, {msg:"init"});
    sendResponse({});
});
